# WordPress-Dev
Collection of custom plugins and themes

## Plugins:
### Color-Code-Time-Slots for Wordpress and Amelia Booking Plugin
#### This plugin allows the admin to colorize time slots on the Amelia booking page to indicate how many people have booked that time slot.

### Display Booked Attendees Plugin for WordPress and Amelia Booking Plugin.
#### This plugin effectively pulls data from the WP database to list the customers who have signed up for any given time slot and display their info on the customer's front end schedule page.
